import csv

from django.shortcuts import render


def inflation_view(request):
    template_name = 'inflation.html'
    data = []
    years = []
    summary = []
    with open('inflation_russia.csv', newline='') as csvfile:
        reader = csv.reader(csvfile, delimiter=';')
        table_header = next(reader)
        for row in reader:
            data.append(row[1:-1])
            years.append(row[0])
            summary.append(row[-1])

    context = {'data': zip(years, data, summary), 'table_header': table_header, 'years': years, 'summary': summary}

    return render(request,
                  template_name,
                  context)
