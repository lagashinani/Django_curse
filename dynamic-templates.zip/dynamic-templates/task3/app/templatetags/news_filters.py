import time
import datetime

from django import template


register = template.Library()


@register.filter
def format_date(value):
    if time.time() - value < 10 * 60:
        'только что'
    elif time.time() - value < 24 * 60 * 60:
        return f'{int((time.time() - value) / 60 / 60)} часов назад'
    return datetime.date.fromtimestamp(value).strftime('%Y-%m-%d')


@register.filter
def format_score(value=None, default=''):
    if value is None:
        return default
    if value < -5:
        return 'всё плохо'
    elif value <= 5:
        return 'нейтрально'
    else:
        return 'хорошо'


@register.filter
def format_num_comments(value):
    if value == 0:
        return 'Оставить комментарий'
    elif value <= 50:
        return value
    return '50+'


@register.filter
def format_selftext(text, count):
    return ' '.join(text.split()[count:]) + ' ... ' + ' '.join(text.split()[count:-count])



