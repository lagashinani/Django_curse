from django.contrib import admin
from phones.models import Phone

admin.site.register(Phone)
