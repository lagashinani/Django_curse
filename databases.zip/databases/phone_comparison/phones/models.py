from django.db import models


class Phone(models.Model):
    name = models.CharField(max_length=200)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    os = models.CharField(max_length=40)
    ram = models.IntegerField()
    dpi = models.IntegerField()
    cpu = models.CharField(max_length=200)
    display_size = models.CharField(max_length=40)
    radio = models.BooleanField(default=False)


class Samsung(models.Model):
    pass